<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Learn about IIHC SCHOOL's history, mission, vision, and values. Discover our commitment to excellence in education and student development.">
    <title>About Us - IIHC SCHOOL</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <!-- Add AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
     <link rel="icon" href="pics/favicon.ico" type="image/x-icon">
</head>

<body>

    <a href="#main-content" class="visually-hidden focusable">Skip to main content</a>

    <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="Index1.html">
                <img src="pics/LOGO.jpg" alt="IIHC Logo" class="me-2" style="height: 40px;">
                IIHC SCHOOL
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="Index1.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="About Us1.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="programs1.php">Academic</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contact1.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="Directory.php">Directory</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="admissionDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Admission
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="admissionDropdown">
                            <li><a class="dropdown-item" href="registration.php">Registration</a></li>
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="admission1.php">Admission Info</a></li>
                        </ul>
                    </li>
                </ul>
               <form class="d-flex ms-lg-3" id="navbar-search-form" role="search">
          <label for="navbar-search-input" class="visually-hidden">Search</label>
          <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search" id="navbar-search-input" name="query" />
          <button class="btn btn-outline-primary" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </form>
          </div>
        </div>
    </nav>
    <!-- Improved About Us Header -->
    <header class="page-header contact-header py-5"
        style="background: linear-gradient(90deg, var(--gold), var(--secondary-color), #fff); border-bottom-left-radius: 32px; border-bottom-right-radius: 32px;">
        <div class="container text-center">
            <h1 class="section-gradient-heading mb-3" style="font-size:2.5rem;">About Us</h1>
            <p class="lead" style="max-width:700px;margin:0 auto;">
                Welcome to IIHC SCHOOL! Learn about our rich history, our mission to empower students, and our vision
                for a brighter future. Discover the values and commitment that make our educational community unique.
            </p>
        </div>
    </header>

    <main id="main-content">
        <div class="container-fluid py-5"></div>

        <section class="mb-5 section-padding section-blue" data-aos="fade-up">
            <div class="container">
                <h2 class="section-gradient-heading text-center mb-4">Our Story</h2>
                <div class="section-divider"></div>
                <div class="row align-items-center">
                    <div class="col-md-6 order-md-1 order-2">
                        <p>Founded in 2009, IIHC SCHOOL has grown from a small institution into a leading provider of
                            [mention type of education, e.g., innovative and creative education, technical-vocational
                            training. Our journey began with a commitment to Maria Santos, empowering students with
                            practical skills, fostering ethical leadership. Over the years, we have mention key
                            milestones or achievements, e.g., expanded our program offerings, achieved notable
                            accreditations, built strong community partnerships.</p>
                        <p>Today, we continue to uphold our founding principles while embracing modern educational
                            approaches to prepare students for success in a rapidly changing world.</p>
                    </div>
                    <div
                        class="col-md-6 text-center order-md-2 order-1 mb-4 mb-md-0 d-flex align-items-center justify-content-center">
                        <img src="pics/school history.jpg" alt="Image representing school history"
                            class="img-fluid rounded shadow-sm" style="max-height: 260px; object-fit: cover;"
                            data-aos="zoom-in">
                    </div>
                </div>
            </div>
        </section>

        <section class="mb-5 section-padding section-blue" data-aos="fade-up">
            <h2 class="section-gradient-heading text-center mb-4">Our Guiding Principles</h2>
            <div class="section-divider"></div>
            <div class="row">
                <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card card-colorful h-100 text-center">
                        <div class="card-body d-flex flex-column">
                            <span class="icon-bg"><i class="fas fa-bullseye"></i></span>
                            <h3 class="card-title">Our Mission</h3>
                            <p class="card-text">To generate world-class professionals competently equipped to become
                                ethical and compassionate leaders committed to the service of the country and global
                                community. We achieve this by [mention how, e.g., providing rigorous academic programs,
                                fostering a supportive learning environment, encouraging community engagement].</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card card-colorful h-100 text-center">
                        <div class="card-body d-flex flex-column">
                            <span class="icon-bg"><i class="fas fa-eye"></i></span>
                            <h3 class="card-title">Our Vision</h3>
                            <p class="card-text">A globally competitive leader in providing and advocating innovative
                                and creative education, community development, professional and ethical leaders under
                                the divine guidance of the Almighty. We aspire to be recognized for [mention
                                aspirations, e.g., academic excellence, impactful research, graduates' success].</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="card card-colorful h-100 text-center">
                        <div class="card-body d-flex flex-column">
                            <span class="icon-bg"><i class="fas fa-gem"></i></span>
                            <h3 class="card-title">Our Values</h3>
                            <p class="card-text">Our community is built on a foundation of core values:</p>
                            <ul class="list-unstyled text-start mt-3 flex-grow-1">
                                <li><i class="fas fa-check-circle text-success me-2"></i><strong>Respect:</strong>
                                    Treating everyone with dignity and understanding.</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i><strong>Integrity:</strong>
                                    Upholding honesty and ethical behavior.</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i><strong>Excellence:</strong>
                                    Striving for the highest standards in all we do.</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i><strong>Collaboration:</strong>
                                    Working together to achieve common goals.</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i><strong>Innovation:</strong>
                                    Embracing new ideas and approaches to learning.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="mb-5 section-padding section-yellow" data-aos="fade-up">
            <h2 class="section-gradient-heading text-center mb-4">Our Leadership</h2>
            <div class="section-divider"></div>
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="leadership-item d-flex flex-column flex-md-row align-items-center bg-light p-4 rounded shadow-sm"
                        data-aos="fade-up">
                        <img src="pics/principal.jpg" alt="Image of Principal Maria Santos"
                            class="rounded-circle me-md-4 mb-4 mb-md-0">
                        <div>
                            <h3>Maria Santos</h3>
                            <p class="lead text-muted">School Principal</p>
                            <p>Welcome message from Principal Santos. With over 20 years of experience in education,
                                Maria Santos is dedicated to fostering a nurturing and challenging environment at IIHC
                                SCHOOL. Her leadership is guided by a commitment to student success, innovative teaching
                                practices, and community engagement. She believes in empowering every student to reach
                                their full potential and become responsible global citizens.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="mb-5 section-padding section-green" data-aos="fade-up">
            <h2 class="section-gradient-heading text-center mb-4">Our Campus and Facilities</h2>
            <div class="section-divider"></div>
            <p class="text-center mb-5 text-muted lead">Explore the spaces where learning and growth happen.</p>
            <div class="row justify-content-center">
                <div class="col-md-4 mb-4" data-aos="zoom-in">
                    <div class="card card-colorful h-100 facility-card">
                        <img src="pics/r1.jpg" class="card-img-top" alt="Modern Classroom Facility">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Modern Classrooms</h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card card-colorful h-100 facility-card">
                        <img src="pics/computer lab.jpg" class="card-img-top" alt="Specialized Laboratory Facility">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Specialized Laboratories</h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card card-colorful h-100 facility-card">
                        <img src="pics/library.jpg" class="card-img-top" alt="School Library">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Library and Learning Resources</h5>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="mb-5 section-padding section-gradient" data-aos="fade-up">
            <h2 class="section-gradient-heading text-center mb-4">Accreditation and Financial Assistance</h2>
            <div class="section-divider"></div>
            <div class="row">
                <div class="col-md-6 mb-4" data-aos="fade-right">
                    <div class="p-4 rounded shadow-sm h-100">
                        <h3>Accreditation</h3>
                        <p>IIHC SCHOOL is proud to be recognized by various accrediting bodies, ensuring that our
                            programs meet the highest standards of quality and excellence. Our commitment to continuous
                            improvement and adherence to educational best practices is reflected in our accreditations.
                        <ul class="list-unstyled">
                            <li><i class="fas fa-award text-warning me-2"></i><strong>Commission on Higher Education
                                    (CHED):</strong> Integrated Innovation and Hospitality College (IIHC) is committed
                                to delivering quality education that meets national and institutional standards. The
                                college is recognized by the Department of Education (DepEd) and adheres to the
                                prescribed curriculum and educational policies set by the Philippine government. Ongoing
                                efforts are being made to obtain further accreditation from reputable educational
                                agencies to continuously improve the standard of instruction and institutional quality.
                            </li>
                            <li><i class="fas fa-certificate text-success me-2"></i><strong>Technical Education and
                                    Skills Development Authority (TESDA):</strong>IIHC is also recognized as a
                                TESDA-accredited assessment center, authorized to conduct competency assessments for
                                various qualifications. This enables students and professionals to obtain National
                                Certificates (NC) upon successful assessment, enhancing their employability.</li>
                            <li><i class="fas fa-university text-info me-2"></i><strong>Department of Education
                                    (DepEd):</strong>IIHC is a recognized institution under the Department of Education,
                                offering Senior High School programs that comply with the K-12 curriculum. Our programs
                                are designed to provide students with a well-rounded education, preparing them for higher
                                education or employment.</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 mb-4" data-aos="fade-left">
                    <div class="p-4 rounded shadow-sm h-100">
                        <h3>Tuition and Financial Assistance</h3>
                        <p>We believe that quality education should be accessible. IIHC SCHOOL participates in the
                            Department of Education's Senior High School Voucher Program, providing opportunities for
                            eligible public school students to enroll with reduced or zero tuition fees. Benefits for
                            voucher recipients may include:</p>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle text-primary me-2"></i>Free Tuition</li>
                            <li><i class="fas fa-check-circle text-primary me-2"></i>Uniforms</li>
                            <li><i class="fas fa-check-circle text-primary me-2"></i>ID Cards</li>
                            <li><i class="fas fa-check-circle text-primary me-2"></i>Modules</li>
                            <li><i class="fas fa-check-circle text-primary me-2"></i>Access to Laboratories</li>
                        </ul>
                        <p class="mt-3">Additionally, students enrolling in our TESDA programs may be eligible for free
                            training and assessment under specific government programs. Please contact our admissions
                            office for the latest information on eligibility and application procedures.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- New Stats Section -->
        <section class="stats-section section-padding" data-aos="fade-up">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <div class="stat-number" data-count="1000">0</div>
                            <div class="stat-label">Students</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <div class="stat-number" data-count="50">0</div>
                            <div class="stat-label">Faculty Members</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <div class="stat-number" data-count="20">0</div>
                            <div class="stat-label">Programs</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <div class="stat-number" data-count="95">0</div>
                            <div class="stat-label">Success Rate</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        </div>
    </main>

    <!-- Back to Top Button -->
    <button id="back-to-top" class="back-to-top" aria-label="Back to top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <footer>
        <div class="container">
            <div class="row text-center text-md-start">
                <div class="col-md-4 mb-4">
                    <h3 class="fw-bold mb-2" style="font-size: 1.3rem;">IIHC COLLEGE</h3>
                    <p class="text-muted mb-0">Providing quality senior high school education...</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h3 class="fw-bold mb-2" style="font-size: 1.3rem;">Quick Links</h3>
                     <ul class="footer-links">
                    <li><a href="Index1.php">Home</a></li>
                    <li><a href="About Us1.php">About</a></li>
                    <li><a class="active" href="programs1.php">Academic</a></li>
                    <li><a href="Contact1.php">Contact</a></li>
                    <li><a href="Directory.php">Directory</a></li>
                    <li><a href="admission1.php">Admission Info</a></li>
                    <li><a href="registration.php">Registration</a></li>
                    <li><a href="login.php">Login</a></li>
                
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h3 class="fw-bold mb-2" style="font-size: 1.3rem;">Contact Info</h3>
                    <address class="mb-0">
                        <p class="mb-2"><i class="fas fa-map-marker-alt fa-fw me-2 text-primary"></i>Blk 4 Lot 6 La
                            Forteza Subdivision Camarin Brgy 175 District 1, Philippines</p>
                        <p class="mb-2"><i class="fas fa-phone-alt fa-fw me-2 text-success"></i>0967 892 9232</p>
                        <p class="mb-0"><i class="fas fa-envelope fa-fw me-2 text-danger"></i><a
                                href="mailto:iihclaforteza@gmail.com" class="footer-link">iihclaforteza@gmail.com</a>
                        </p>
                    </address>
                </div>
            </div>
            <hr>
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
                <p class="mb-2 mb-md-0 small text-muted">© 2025 by IIH COLLEGE. All rights reserved.</p>
                <div class="footer-legal-links small">
                    <a href="#" class="footer-link" data-bs-toggle="modal" data-bs-target="#privacyPolicyModal">Privacy Policy</a> |
                    <a href="#" class="footer-link">Data Policy</a> |
                </div>
            </div>
        </div>
    </footer>

    <!-- Privacy Policy Modal -->
    <div class="modal fade privacy-popup" id="privacyPolicyModal" tabindex="-1" aria-labelledby="privacyPolicyModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="privacyPolicyModalLabel">
                        <i class="fas fa-lock me-2"></i> Privacy Notice
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>In accordance with the Data Privacy Act of 2012 (RA 10173), IIHC SCHOOL would like to obtain your
                        consent for:</p>

                    <ul class="privacy-list mb-3">
                        <li>Collection and processing of student information</li>
                        <li>Use of educational records and academic data</li>
                        <li>Website analytics and performance tracking</li>
                        <li>School communications and updates</li>
                    </ul>

                    <p>Our website uses necessary cookies to enhance your browsing experience and help us improve our
                        services.</p>

                    <div class="contact-info mt-3">
                        <p class="mb-2"><small>For privacy concerns, contact our Data Protection Officer:</small></p>
                        <p class="mb-1"><small><i class="fas fa-envelope me-2"></i>iihclaforteza@gmail.com</small>
                        </p>
                        <p class="mb-0"><small><i class="fas fa-phone me-2"></i>0967 892 9232</small></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary w-100" data-bs-dismiss="modal">I ACCEPT</button>
                </div>
            </div>
        </div>
    </div>
<!-- Your existing code above... -->

<!-- Existing content remains untouched -->

<!-- Scripts -->
<script src="js/bootstrap.bundle.min.js"></script>
<!-- Add AOS JS and init -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init({ duration: 800, easing: 'ease-in-out', once: true, mirror: false });
</script>

<!-- Back to Top Button & Stats & Modal & Search Scripts -->
<script>
  // Back to top button
  const backToTop = document.getElementById('back-to-top');
  window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
      backToTop.classList.add('show');
    } else {
      backToTop.classList.remove('show');
    }
  });
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Stats count animation
  const stats = document.querySelectorAll('.stat-number');
  const animateStats = () => {
    stats.forEach(stat => {
      const target = parseInt(stat.getAttribute('data-count'));
      let current = 0;
      const duration = 2000;
      const stepTime = Math.max(20, Math.floor(duration / target));
      const step = () => {
        current += Math.ceil(target / (duration / stepTime));
        if (current >= target) {
          current = target;
        }
        stat.textContent = current;
        if (current < target) {
          setTimeout(step, stepTime);
        }
      };
      step();
    });
  };
  // Animate when stats section in view
  const statsObserver = new IntersectionObserver((entries, obs) => {
    if (entries[0].isIntersecting) {
      animateStats();
      obs.disconnect();
    }
  }, { threshold: 0.5 });
  document.querySelectorAll('.stats-section').forEach(sec => statsObserver.observe(sec));

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const target = document.querySelector(link.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
</script>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('navbar-search-form');
    const searchInput = document.getElementById('navbar-search-input');

    // Create container for search results
    const resultsContainer = document.createElement('div');
    resultsContainer.id = 'search-results-container';
    resultsContainer.className = 'search-results-container position-absolute bg-white border p-2 rounded d-none';
    resultsContainer.style.top = '60px';
    resultsContainer.style.right = '20px';
    resultsContainer.style.width = '300px';
    resultsContainer.style.zIndex = '1050';
    document.body.appendChild(resultsContainer);

    let debounceTimer;

    function escapeRegex(str) {
      return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function removeHighlights() {
      document.querySelectorAll('.search-highlight').forEach(span => {
        const parent = span.parentNode;
        parent.replaceChild(document.createTextNode(span.textContent), span);
        parent.normalize();
      });
    }

    function performSearch(query) {
      removeHighlights();
      resultsContainer.innerHTML = '';
      resultsContainer.classList.add('d-none');

      const trimmedQuery = query.trim();
      if (trimmedQuery.length < 3) return;

      const elements = document.querySelectorAll('p, li, h1, h2, h3, h4, h5, h6, td, th, a, span, .card-text');
      const results = [];
      let firstMatchedElement = null;

      const regex = new RegExp(`(${escapeRegex(trimmedQuery)})`, 'gi');

      elements.forEach(el => {
        const originalHTML = el.innerHTML;
        const text = el.textContent;

        if (text.toLowerCase().includes(trimmedQuery.toLowerCase())) {
          // Highlight all matches
          el.innerHTML = originalHTML.replace(regex, '<span class="search-highlight">$1</span>');
          
          // Assign a unique ID if none
          if (!el.id) {
            el.id = 'search-highlight-' + Math.random().toString(36).substr(2, 9);
          }
          
          results.push({ element: el, text: text });
          
          // Remember the first match
          if (!firstMatchedElement) {
            firstMatchedElement = el;
          }
        }
      });

      if (results.length > 0) {
        resultsContainer.innerHTML = `
          <div class="small text-muted mb-2">${results.length} results found</div>
          <div class="search-results-list">
            ${results.slice(0, 5).map((res, index) => `
              <div class="search-result-item" style="cursor:pointer;" data-scroll-to="${res.element.id}">Match ${index + 1}</div>
            `).join('')}
          </div>
        `;
        resultsContainer.classList.remove('d-none');

        // Scroll to the first match
        if (firstMatchedElement && firstMatchedElement.id) {
          document.getElementById(firstMatchedElement.id).scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      } else {
        resultsContainer.innerHTML = '<div class="text-muted p-2">No results found</div>';
        resultsContainer.classList.remove('d-none');
      }
    }

    // Event listeners
    searchForm.addEventListener('submit', e => {
      e.preventDefault();
      performSearch(searchInput.value);
    });

    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      if (searchInput.value.length > 2) {
        debounceTimer = setTimeout(() => performSearch(searchInput.value), 250);
      } else {
        removeHighlights();
        resultsContainer.classList.add('d-none');
      }
    });

    resultsContainer.addEventListener('click', e => {
      const item = e.target.closest('.search-result-item');
      if (item) {
        const targetId = item.getAttribute('data-scroll-to');
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        resultsContainer.classList.add('d-none');
      }
    });

    document.addEventListener('click', e => {
      if (!e.target.closest('#navbar-search-form') && !e.target.closest('#search-results-container')) {
        resultsContainer.classList.add('d-none');
      }
    });
  });
</script>
</body>
</html>

